# Package marker for tests importing `src.*`
